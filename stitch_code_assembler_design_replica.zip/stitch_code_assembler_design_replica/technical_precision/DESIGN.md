---
name: Technical Precision
colors:
  surface: '#f9f9f9'
  surface-dim: '#dadada'
  surface-bright: '#f9f9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f3'
  surface-container: '#eeeeee'
  surface-container-high: '#e8e8e8'
  surface-container-highest: '#e2e2e2'
  on-surface: '#1a1c1c'
  on-surface-variant: '#5b4138'
  inverse-surface: '#2f3131'
  inverse-on-surface: '#f1f1f1'
  outline: '#8f7066'
  outline-variant: '#e4beb2'
  surface-tint: '#ab3600'
  primary: '#a73400'
  on-primary: '#ffffff'
  primary-container: '#d14400'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb59c'
  secondary: '#5e5e61'
  on-secondary: '#ffffff'
  secondary-container: '#e3e2e5'
  on-secondary-container: '#646467'
  tertiary: '#005bb1'
  on-tertiary: '#ffffff'
  tertiary-container: '#0073de'
  on-tertiary-container: '#fefcff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbcf'
  primary-fixed-dim: '#ffb59c'
  on-primary-fixed: '#390c00'
  on-primary-fixed-variant: '#822700'
  secondary-fixed: '#e3e2e5'
  secondary-fixed-dim: '#c7c6c9'
  on-secondary-fixed: '#1b1c1e'
  on-secondary-fixed-variant: '#464749'
  tertiary-fixed: '#d6e3ff'
  tertiary-fixed-dim: '#a9c7ff'
  on-tertiary-fixed: '#001b3d'
  on-tertiary-fixed-variant: '#00468b'
  background: '#f9f9f9'
  on-background: '#1a1c1c'
  surface-variant: '#e2e2e2'
  agent-orange: '#EC4E02'
  terminal-black: '#07080A'
  surface-gray: '#F2F2F2'
  border-subtle: '#E5E5E5'
typography:
  headline-lg:
    fontFamily: geist
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: geist
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.2'
  headline-md:
    fontFamily: geist
    fontSize: 20px
    fontWeight: '500'
    lineHeight: '1.4'
  body-md:
    fontFamily: ibmPlexSans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.6'
  body-sm:
    fontFamily: ibmPlexSans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: '1.5'
  label-mono:
    fontFamily: jetbrainsMono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1'
    letterSpacing: 0.05em
  code-block:
    fontFamily: jetbrainsMono
    fontSize: 13px
    fontWeight: '400'
    lineHeight: '1.6'
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 16px
  margin-mobile: 16px
  margin-desktop: 32px
  container-max: 1200px
---

## Brand & Style

This design system is built for technical environments, developer tools, and agentic workflows. It prioritizes clarity, efficiency, and a "low-latency" visual feel. The brand personality is clinical, authoritative, and sophisticated, avoiding unnecessary decoration in favor of structural integrity and functional density.

The aesthetic leans into **Minimalism** with a **Technical/Brutalist** edge. It utilizes high-contrast layouts, expansive whitespace, and monospaced accents to evoke the precision of a code editor. A key visual differentiator is the use of ASCII-inspired graphic elements and monospaced structural grids, which bridge the gap between legacy terminal interfaces and modern high-fidelity software.

## Colors

The palette is strictly functional. The primary color, **Agent Orange (#EC4E02)**, is reserved for high-significance semantic markers—specifically the "Agent" status badges and primary call-to-actions. It is a high-energy, industrial hue that demands attention against a grayscale backdrop.

The neutral foundation relies on **Terminal Black (#07080A)** for text and high-contrast UI elements, and **Surface Gray (#F2F2F2)** for background regions. This creates a high-legibility environment where depth is communicated through subtle shifts in gray rather than vibrant color. Accent colors should be used sparingly, almost exclusively for syntax highlighting or status indicators.

## Typography

The typography system is a hierarchy of utility. **Geist** provides a clean, technical sharp-edge for headlines, ensuring that titles feel modern and precise. **IBM Plex Sans** is used for the majority of body copy; its systematic, corporate design ensures comfortable long-form reading and clear data presentation.

The standout element of the design system is the use of **JetBrains Mono** for labels, metadata, and status badges. This monospaced font introduces a "hacker-tool" aesthetic into the interface. All mono-labels should be set in uppercase with a slight letter-spacing increase to emphasize their role as metadata.

## Layout & Spacing

This design system employs a **Fixed Grid** model for primary content containers, centered within the viewport. The layout follows a 12-column structure on desktop with 16px gutters, allowing for modular blocks that mimic a code-IDE workspace.

Spacing follows a strict 4px base unit. Components are grouped using "density-first" logic—related items are tightly packed with minimal padding (8px-12px), while distinct functional sections are separated by large, generous gaps (48px+) to maintain a minimalist, uncluttered feel. On mobile, the 12-column grid collapses to a single column with 16px side margins.

## Elevation & Depth

Hierarchy is achieved through **Low-Contrast Outlines** and **Tonal Layers** rather than shadows. In this design system, shadows are almost non-existent to maintain a flat, technical aesthetic. 

- **Level 0 (Background):** Surface Gray (#F2F2F2).
- **Level 1 (Cards/Inputs):** Pure White (#FFFFFF) with a 1px border of Border-Subtle (#E5E5E5).
- **Level 2 (Popovers/Modals):** Pure White with a sharp, 2px solid Terminal Black border and zero-blur offset shadow (e.g., 4px 4px 0px black) to create a "brutalist" stack effect.

Depth is also suggested through "ASCII Art" dividers—lines composed of dashes, dots, or slashes that act as horizontal rules between sections.

## Shapes

The shape language is primarily **Sharp**. A "Soft" rounding (0.25rem) is applied only to interactive components like buttons and input fields to provide a slight tactile affordance and prevent the UI from feeling overly aggressive.

Badges and status indicators (like the "Agent" badge) use a `rounded-sm` or `rounded-none` setting to maintain a structured, blocky feel. Graphics and containers should prioritize 90-degree angles to reinforce the grid-based, technical nature of the system.

## Components

### Buttons
Primary buttons use a solid **Terminal Black** background with white text for maximum contrast. Secondary buttons use a white background with a 1px gray border. Hover states are indicated by a slight shift in background tone or a solid 1px offset "shadow" box.

### The "Agent" Badge
A signature component of the design system. It is a small, rectangular badge with a background of **Agent Orange (#EC4E02)** and bold white text in **JetBrains Mono**. It should always be uppercase.

### Input Fields
Inputs are minimalist: a simple 1px bottom border or a full 1px border in a light gray. Focus states should switch the border to Terminal Black or Agent Orange.

### ASCII Visuals
Decorative elements should be constructed from characters (e.g., `+---+`, `|`, `>`). Use these for headers or as unique dividers to separate the hero section from the main content.

### Cards
Cards are flat white surfaces with subtle 1px borders. They do not use shadows. Information density inside cards should be high, utilizing monospaced labels for all technical data points.